export const userRoles = {
    hiredEmployee: "Hired Employee",
    superAdmin: "Super Admin",
    systemAdmin:"System Admin",
    supervisor: "Supervisor",
    contentCreator:"Content Creator"
}