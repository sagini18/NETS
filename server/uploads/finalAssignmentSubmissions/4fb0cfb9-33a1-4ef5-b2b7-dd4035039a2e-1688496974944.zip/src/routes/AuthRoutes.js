import GoogleLogin from "../pages/login/GoogleLogin";

export const auth_routes = [
    { 
        path: "/", 
        ele: <GoogleLogin />, 
    },
    { 
        path: "/login", 
        ele: <GoogleLogin />, 
    }
]