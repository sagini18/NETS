import React from "react";
import ListAllChapters from "../chapter/ListAllChapters";
const HiredEmployee = () => {
    return (
        <ListAllChapters />
    );
}
export default HiredEmployee;